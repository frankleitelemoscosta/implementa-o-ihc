# Resumo do piloto (dados SINTÉTICOS)

| Tarefa | Condição | Agente | N | S | AI | R_enq | Ā | A_KLM | Ū | T_sim (s) | T_KLM (s) | L med (ms) |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| C1 | comparador | ollama | 10/10 | 0.80 | 0.00 | 0.00 | 10.90 | 5 | 1.30 | 64.86 | 19.11 | 20926.00 |
| C1 | generico | ollama | 10/10 | 0.00 | 1.00 | 0.00 | 13.10 | 5 | 2.60 | 82.32 | 19.11 | 12896.00 |
| C1 | perfil | ollama | 10/10 | 0.00 | 1.00 | 0.00 | 11.90 | 5 | 1.30 | 48.26 | 19.11 | 20808.50 |
| C2 | perfil | ollama | 6/6 | 0.00 | 1.00 | 0.50 | 20.33 | 9 | 3.33 | 114.40 | 52.16 | 14958.25 |

## Rupturas MAC (contagem por assinatura no log)

| Tarefa | Condição | Cadê? | Epa! | Onde estou? | E agora? | O que é isto? | Por que não funciona? | Ué, o que houve? | Socorro! | Para mim está bom | Desisto |
|---|---|---|---|---|---|---|---|---|---|---|---|
| C1 | comparador | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| C1 | generico | 7 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 2 | 0 |
| C1 | perfil | 6 | 0 | 7 | 1 | 0 | 0 | 0 | 0 | 2 | 2 |
| C2 | perfil | 6 | 0 | 3 | 0 | 0 | 1 | 0 | 0 | 3 | 0 |

## Linha de base KLM (especialista)

- C1: 5 ações, 19.11 s — operadores: `MKR MPR PR MKR MKR`
- C2: 9 ações, 52.16 s — operadores: `MKR MKR MKR MKR MKR MPR MKR MKR MKR`
