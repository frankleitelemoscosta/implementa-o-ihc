# E3 — Pacote de Dados do Piloto (UX-Agent)

Dados **SINTÉTICOS** gerados por agente proxy LLM. Não representam desempenho de pessoas com deficiência visual.

- `logs/*.events.jsonl` — um evento JSON por linha (dicionário em `event-dictionary.md`).
- `logs/*.prompts.jsonl` — prompt de sistema, prompt do passo, schema de saída (enum das falas u:) e resposta bruta, por passo.
- `logs/manifest.jsonl` — uma linha por execução (parâmetros sorteados θ, semente, fim).
- `logs/verification.jsonl` — veredito do verificador EXTERNO (estado final da interface).
- `metrics/` — métricas por execução e por tarefa × condição; rupturas MAC por assinatura.
- `config.yaml` — configuração usada (SHA-256 13ce7836825752897979b1f459fccd4ef4041a5fe9308688fc5dd3bd4bc0d2c2).

Somente tarefas de **calibração** (C1, C2). V1 e V2 permanecem reservadas.
